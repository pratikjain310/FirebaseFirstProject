//
//  ViewController.swift
//  FireBaseExample
//
//  Created by ashutosh deshpande on 05/12/2022.
//

import UIKit
import FirebaseAuth
class ViewController: UIViewController {
    var windows = UIWindow()
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = false
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        usernameTextField.text = ""
        passwordTextField.text = ""
        let user = Auth.auth().currentUser;
        if user != nil {
            let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as! MainTabBarController
            let window = UIApplication.shared.windows[0] as UIWindow
            UIView.transition(from: (window.rootViewController?.view)!, to: secondViewController.view, duration: 0.65, options: .transitionCrossDissolve) { bool in
                window.rootViewController = secondViewController
            }
        }
    }
    
    func isValidUserName(testStr: String) -> Bool {
        let emailRegEx = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{1,4}$"
        let emailTest = NSPredicate(format: "SELF MATCHES[c] %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    @IBAction func signInButton(_ sender: Any) {
        if usernameTextField.text?.isEmpty == true &&  passwordTextField.text?.isEmpty == true {
            let act = UIAlertController(title: "Alert!", message: "Please enter all the Details", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
            return
        }
        if !isValidUserName(testStr: usernameTextField.text ?? ""){
            let act = UIAlertController(title: "Alert!", message: "Please enter valid Email", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
            return
        }
        Auth.auth().signIn(withEmail: usernameTextField.text!, password: passwordTextField.text!) { [unowned self] result, error in
            if error == nil{
                if result?.user.email == usernameTextField.text{
                    let act = UIAlertController(title: "Alert!", message: "Sign In Successful", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "Ok", style: .default) { [unowned self] (alert) in
                        //                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as! MainTabBarController
                        //                        self.navigationController?.pushViewController(vc, animated: true)
                        //                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                        //                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "MainTabBarController") as! MainTabBarController
                        //                        self.present(nextViewController, animated:true, completion:nil)
                        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as! MainTabBarController
                        let window = UIApplication.shared.windows[0] as UIWindow
                        UIView.transition(from: (window.rootViewController?.view)!, to: secondViewController.view, duration: 0.65, options: .transitionCrossDissolve) { bool in
                            window.rootViewController = secondViewController
                        }
                    }
                    act.addAction(okAction)
                    present(act, animated: true)
                }
            }else {
                let act = UIAlertController(title: "Alert!", message: "\(error?.localizedDescription ?? "Error Occured")", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                act.addAction(okAction)
                present(act, animated: true)
            }
            
        }
        
        //        windows.rootViewController = storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as! MainTabBarController
        //        windows.makeKeyAndVisible()
        
    }
    
    @IBAction func forgotPasswordButton(_ sender: Any) {
        if usernameTextField.text?.isEmpty == true{
            let act = UIAlertController(title: "Alert!", message: "Please enter Email ID", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
            return
        }
        if !isValidUserName(testStr: usernameTextField.text ?? ""){
            let act = UIAlertController(title: "Alert!", message: "Please enter valid Email", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
            return
        }
        Auth.auth().sendPasswordReset(withEmail: usernameTextField.text!) { [unowned self] error in
            if error == nil{
                
                let act = UIAlertController(title: "Alert!", message: "Password Reset Link Send to Mail ID", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                act.addAction(okAction)
                present(act, animated: true)
                
            }else {
                let act = UIAlertController(title: "Alert!", message: "\(error?.localizedDescription ?? "Error Occured")", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                act.addAction(okAction)
                present(act, animated: true)
            }
        }
    }
    
    @IBAction func signUpButton(_ sender: UIButton) {
        let signUpVC = storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        navigationController?.pushViewController(signUpVC, animated: true)
    }
    
    
}

