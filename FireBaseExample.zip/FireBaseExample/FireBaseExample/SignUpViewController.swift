//
//  SignUpViewController.swift
//  FireBaseExample
//
//  Created by ashutosh deshpande on 06/12/2022.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
class SignUpViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func signUpButton(_ sender: Any) {
        if usernameTextField.text?.isEmpty == true &&  passwordTextField.text?.isEmpty == true && confirmPasswordTextField.text?.isEmpty == true{
            let act = UIAlertController(title: "Alert!", message: "Please enter all the Details", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
            return
        }
        
        if !isValidUserName(testStr: usernameTextField.text ?? ""){
            let act = UIAlertController(title: "Alert!", message: "Please enter valid Email", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
            return
        }
        
        if passwordTextField.text != confirmPasswordTextField.text {
            let act = UIAlertController(title: "Alert!", message: "Password And Confirm Password Must be Same", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
            return
        }
        Auth.auth().createUser(withEmail: usernameTextField.text!, password: passwordTextField.text!) { [unowned self] authResult, error in
            if error == nil {
                let act = UIAlertController(title: "Alert!", message: "User Created", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .default) { [unowned self] (alert) in
                    self.navigationController?.popViewController(animated: true)
                }
                act.addAction(okAction)
                present(act, animated: true)
                
            }
        }
        //use database to save login details in firebase
       
        
       
    }
    func isValidUserName(testStr: String) -> Bool {
        let emailRegEx = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{1,4}$"
        let emailTest = NSPredicate(format: "SELF MATCHES[c] %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
}
