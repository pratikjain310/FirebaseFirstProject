//
//  HomeScreenViewController.swift
//  FireBaseExample
//
//  Created by ashutosh deshpande on 06/12/2022.
//

import UIKit
import FirebaseAuth
class HomeScreenViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func logOutButton(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        do{
            try firebaseAuth.signOut()
            let act = UIAlertController(title: "Alert!", message: "LoggedOut Successfully", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default) { [unowned self] (alert) in
                let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "NavigationViewController") as! NavigationViewController
                let window = UIApplication.shared.windows[0] as UIWindow
                UIView.transition(from: (window.rootViewController?.view)!, to: secondViewController.view, duration: 0.65, options: .transitionCrossDissolve) { bool in
                    window.rootViewController = secondViewController
                }
            }
            act.addAction(okAction)
            present(act, animated: true)
        }catch let error {
            let act = UIAlertController(title: "Alert!", message: "\(error.localizedDescription)", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            act.addAction(okAction)
            present(act, animated: true)
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension HomeScreenViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(720.0)
    }
}
